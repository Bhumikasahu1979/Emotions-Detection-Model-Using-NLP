"""Train a small FER2013 facial-expression classifier from an image ZIP.

The exported model uses HOG features and a four-class softmax classifier, so
the website can run inference locally without downloading a large model.
Requires Python, NumPy, and Pillow.
"""

import argparse
import io
import json
import math
import zipfile
from collections import Counter
from pathlib import Path, PurePosixPath

import numpy as np
from PIL import Image


LABELS = ["joy", "sadness", "anger", "fear"]
FER_TO_LABEL = {"happy": "joy", "sad": "sadness", "angry": "anger", "fear": "fear"}
IMAGE_SIZE = 48
CELL_SIZE = 8
ORIENTATIONS = 9


def hog_features(image):
    """Compute a 900-element unsigned HOG descriptor for a 48x48 grayscale image."""
    pixels = np.asarray(image, dtype=np.float32) / 255.0
    gx = np.empty_like(pixels)
    gy = np.empty_like(pixels)

    gx[:, 1:-1] = (pixels[:, 2:] - pixels[:, :-2]) * 0.5
    gx[:, 0] = pixels[:, 1] - pixels[:, 0]
    gx[:, -1] = pixels[:, -1] - pixels[:, -2]
    gy[1:-1, :] = (pixels[2:, :] - pixels[:-2, :]) * 0.5
    gy[0, :] = pixels[1, :] - pixels[0, :]
    gy[-1, :] = pixels[-1, :] - pixels[-2, :]

    magnitude = np.hypot(gx, gy)
    angle = np.mod(np.arctan2(gy, gx), np.pi)
    bin_position = angle * (ORIENTATIONS / np.pi)
    lower_bin = np.floor(bin_position).astype(np.int32) % ORIENTATIONS
    upper_weight = bin_position - np.floor(bin_position)

    yy, xx = np.mgrid[0:IMAGE_SIZE, 0:IMAGE_SIZE]
    cell_index = ((yy // CELL_SIZE) * 6 + (xx // CELL_SIZE)) * ORIENTATIONS
    hist = np.bincount(
        (cell_index + lower_bin).ravel(),
        weights=(magnitude * (1.0 - upper_weight)).ravel(),
        minlength=6 * 6 * ORIENTATIONS,
    )
    hist += np.bincount(
        (cell_index + ((lower_bin + 1) % ORIENTATIONS)).ravel(),
        weights=(magnitude * upper_weight).ravel(),
        minlength=6 * 6 * ORIENTATIONS,
    )
    cells = hist.reshape(6, 6, ORIENTATIONS)

    blocks = []
    for row in range(5):
        for col in range(5):
            block = cells[row : row + 2, col : col + 2, :].reshape(-1).astype(np.float32)
            block /= math.sqrt(float(np.dot(block, block)) + 1e-6)
            np.minimum(block, 0.2, out=block)
            block /= math.sqrt(float(np.dot(block, block)) + 1e-6)
            blocks.append(block)
    return np.concatenate(blocks)


def split_and_label(filename):
    """Find FER2013 train/test split and map its folder label to a target class."""
    parts = [part.lower() for part in PurePosixPath(filename).parts]
    split_index = next((i for i, part in enumerate(parts) if part in ("train", "test")), None)
    if split_index is None or split_index + 1 >= len(parts):
        return None, None
    return parts[split_index], FER_TO_LABEL.get(parts[split_index + 1])


def load_features(zip_path):
    features = {"train": [], "test": []}
    targets = {"train": [], "test": []}
    counts = {"train": Counter(), "test": Counter()}
    skipped = 0

    with zipfile.ZipFile(zip_path) as archive:
        image_entries = [
            item
            for item in archive.infolist()
            if not item.is_dir() and item.filename.lower().endswith((".jpg", ".jpeg", ".png"))
        ]
        total = len(image_entries)
        print(f"Reading {total:,} image files from {zip_path}")

        for index, item in enumerate(image_entries, start=1):
            split, label = split_and_label(item.filename)
            if split is None or label is None:
                continue
            try:
                with archive.open(item) as file:
                    image = Image.open(io.BytesIO(file.read())).convert("L")
                    image = image.resize((IMAGE_SIZE, IMAGE_SIZE), Image.Resampling.BILINEAR)
                    features[split].append(hog_features(image))
                    targets[split].append(LABELS.index(label))
                    counts[split][label] += 1
            except Exception as error:
                skipped += 1
                print(f"Skipping unreadable image {item.filename}: {error}")

            if index % 3000 == 0 or index == total:
                print(f"  processed {index:,}/{total:,} files")

    arrays = {
        split: (np.asarray(features[split], dtype=np.float32), np.asarray(targets[split], dtype=np.int64))
        for split in ("train", "test")
    }
    return arrays, counts, skipped


def softmax(logits):
    shifted = logits - np.max(logits, axis=1, keepdims=True)
    values = np.exp(shifted)
    return values / np.sum(values, axis=1, keepdims=True)


def train_classifier(x_train, y_train, epochs=28, batch_size=256, learning_rate=0.012):
    rng = np.random.default_rng(42)
    classes = len(LABELS)
    weights = rng.normal(0.0, 0.002, size=(x_train.shape[1], classes)).astype(np.float32)
    bias = np.zeros(classes, dtype=np.float32)
    first_weight = np.zeros_like(weights)
    second_weight = np.zeros_like(weights)
    first_bias = np.zeros_like(bias)
    second_bias = np.zeros_like(bias)
    beta1, beta2 = 0.9, 0.999
    step = 0
    class_counts = np.bincount(y_train, minlength=classes).astype(np.float32)
    class_weights = len(y_train) / (classes * class_counts)
    one_hot = np.eye(classes, dtype=np.float32)

    for epoch in range(1, epochs + 1):
        order = rng.permutation(len(y_train))
        total_loss = 0.0

        for start in range(0, len(order), batch_size):
            indices = order[start : start + batch_size]
            batch_x = x_train[indices]
            batch_y = y_train[indices]
            probabilities = softmax(batch_x @ weights + bias)
            sample_weights = class_weights[batch_y]
            sample_weights /= np.mean(sample_weights)
            total_loss += float(
                np.sum(-np.log(np.maximum(probabilities[np.arange(len(batch_y)), batch_y], 1e-8)) * sample_weights)
            )
            gradient = probabilities - one_hot[batch_y]
            gradient *= sample_weights[:, None] / len(batch_y)
            grad_w = batch_x.T @ gradient + 0.0005 * weights
            grad_b = np.sum(gradient, axis=0)

            step += 1
            first_weight = beta1 * first_weight + (1.0 - beta1) * grad_w
            second_weight = beta2 * second_weight + (1.0 - beta2) * (grad_w * grad_w)
            first_bias = beta1 * first_bias + (1.0 - beta1) * grad_b
            second_bias = beta2 * second_bias + (1.0 - beta2) * (grad_b * grad_b)
            corrected_first_w = first_weight / (1.0 - beta1**step)
            corrected_second_w = second_weight / (1.0 - beta2**step)
            corrected_first_b = first_bias / (1.0 - beta1**step)
            corrected_second_b = second_bias / (1.0 - beta2**step)
            weights -= learning_rate * corrected_first_w / (np.sqrt(corrected_second_w) + 1e-8)
            bias -= learning_rate * corrected_first_b / (np.sqrt(corrected_second_b) + 1e-8)

        mean_loss = total_loss / len(y_train)
        print(f"Epoch {epoch:02}/{epochs} · weighted loss {mean_loss:.4f}")

    return weights, bias


def score_classifier(x, y, weights, bias):
    probabilities = softmax(x @ weights + bias)
    predictions = np.argmax(probabilities, axis=1)
    accuracy = float(np.mean(predictions == y))
    confusion = np.zeros((len(LABELS), len(LABELS)), dtype=np.int64)
    for truth, prediction in zip(y, predictions):
        confusion[truth, prediction] += 1
    return accuracy, confusion


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("dataset_zip", type=Path, help="FER2013 ZIP with train/test class folders")
    parser.add_argument("--output", type=Path, default=Path(__file__).with_name("image_model.json"))
    parser.add_argument("--epochs", type=int, default=28)
    args = parser.parse_args()

    if not args.dataset_zip.is_file():
        parser.error(f"Dataset ZIP does not exist: {args.dataset_zip}")

    datasets, counts, skipped = load_features(args.dataset_zip)
    x_train, y_train = datasets["train"]
    x_test, y_test = datasets["test"]
    if not len(x_train) or not len(x_test):
        raise SystemExit("The ZIP needs labelled train/ and test/ folders with FER2013 class names.")

    print("Training a four-class HOG + softmax image classifier")
    weights, bias = train_classifier(x_train, y_train, epochs=args.epochs)
    accuracy, confusion = score_classifier(x_test, y_test, weights, bias)
    print(f"Held-out test accuracy: {accuracy:.1%}")
    print("Confusion matrix (rows=true, columns=predicted):")
    print("          " + " ".join(f"{label:>8}" for label in LABELS))
    for label, row in zip(LABELS, confusion):
        print(f"{label:>8}  " + " ".join(f"{value:8d}" for value in row))

    report = {
        "model_version": "fer2013-hog-softmax-v1",
        "labels": LABELS,
        "image_size": IMAGE_SIZE,
        "cell_size": CELL_SIZE,
        "orientations": ORIENTATIONS,
        "feature_count": int(weights.shape[0]),
        "training_examples": int(len(y_train)),
        "test_examples": int(len(y_test)),
        "train_counts": dict(counts["train"]),
        "test_counts": dict(counts["test"]),
        "test_accuracy": accuracy,
        "confusion_matrix": confusion.tolist(),
        "skipped_images": skipped,
    }
    exported = {
        **report,
        "weights": np.round(weights, 8).tolist(),
        "bias": np.round(bias, 8).tolist(),
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(exported, separators=(",", ":")), encoding="utf-8")
    print(f"Saved browser model: {args.output}")


if __name__ == "__main__":
    main()
