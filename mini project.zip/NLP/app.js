const EMOTIONS = ["joy", "sadness", "anger", "fear"];
const $ = (id) => document.getElementById(id);

const elements = {
  textTab: $("textTab"), imageTab: $("imageTab"), textMode: $("textMode"), imageMode: $("imageMode"),
  textInput: $("textInput"), charCount: $("charCount"), analyzeText: $("analyzeText"),
  imageInput: $("imageInput"), dropzone: $("dropzone"), dropzoneEmpty: $("dropzoneEmpty"),
  previewWrap: $("previewWrap"), imagePreview: $("imagePreview"), imageFileName: $("imageFileName"),
  analyzeImage: $("analyzeImage"), modelStatus: $("modelStatus"), resultEmpty: $("resultEmpty"),
  resultContent: $("resultContent"), resultOrb: $("resultOrb"), resultGlyph: $("resultGlyph"),
  resultTitle: $("resultTitle"), resultExplanation: $("resultExplanation"), scoreList: $("scoreList"),
  resultDisclaimer: $("resultDisclaimer"),
};

let textModel = null;
let imageModel = null;
let currentImageUrl = null;
let textModelStatus = "Text model loading";
let imageModelStatus = "Image model loading";

function updateModelStatus() {
  elements.modelStatus.textContent = `${textModelStatus} · ${imageModelStatus}`;
}

const EMOTION_META = {
  joy: { glyph: "✦", explanation: "An upbeat signal in the words or expression." },
  happy: { glyph: "✦", display: "Joy", explanation: "A positive expression signal in the image." },
  sadness: { glyph: "☂", explanation: "A low or melancholy signal in the words." },
  sad: { glyph: "☂", display: "Sadness", explanation: "A subdued expression signal in the image." },
  anger: { glyph: "✹", explanation: "A strong, frustrated signal in the words." },
  angry: { glyph: "✹", display: "Anger", explanation: "An intense expression signal in the image." },
  fear: { glyph: "⌁", explanation: "A worried or uncertain signal in the words." },
  neutral: { glyph: "◌", explanation: "A neutral-looking expression signal." },
  disgust: { glyph: "↗", explanation: "A negative expression signal in the image." },
  surprise: { glyph: "✧", explanation: "A surprised expression signal in the image." },
};

function tokenize(text) {
  return text.toLowerCase().match(/[a-z]+/g) || [];
}

function parseCsvLine(line) {
  const cells = [];
  let cell = "";
  let quoted = false;
  for (let i = 0; i < line.length; i += 1) {
    const char = line[i];
    if (char === '"' && line[i + 1] === '"' && quoted) {
      cell += '"';
      i += 1;
    } else if (char === '"') {
      quoted = !quoted;
    } else if (char === "," && !quoted) {
      cells.push(cell);
      cell = "";
    } else {
      cell += char;
    }
  }
  cells.push(cell);
  return cells;
}

function trainTextModel(rows) {
  const documents = Object.fromEntries(EMOTIONS.map((label) => [label, 0]));
  const wordCounts = Object.fromEntries(EMOTIONS.map((label) => [label, new Map()]));
  const wordTotals = Object.fromEntries(EMOTIONS.map((label) => [label, 0]));
  const vocabulary = new Set();

  for (const { text, emotion } of rows) {
    if (!EMOTIONS.includes(emotion)) continue;
    const tokens = tokenize(text);
    documents[emotion] += 1;
    wordTotals[emotion] += tokens.length;
    for (const word of tokens) {
      vocabulary.add(word);
      wordCounts[emotion].set(word, (wordCounts[emotion].get(word) || 0) + 1);
    }
  }

  const totalDocuments = Object.values(documents).reduce((sum, count) => sum + count, 0);
  if (!totalDocuments || vocabulary.size === 0) throw new Error("The labelled sentence dataset could not be read.");
  return { documents, wordCounts, wordTotals, vocabulary, totalDocuments };
}

function predictText(text) {
  if (!textModel) throw new Error("The text dataset is still loading. Try again in a moment.");
  const tokens = tokenize(text);
  if (!tokens.length) throw new Error("Add a few words first, then try again.");
  const size = textModel.vocabulary.size;
  const logScores = {};

  for (const emotion of EMOTIONS) {
    const documentCount = textModel.documents[emotion];
    let score = Math.log(documentCount / textModel.totalDocuments);
    const denominator = textModel.wordTotals[emotion] + size;
    const counts = new Map();
    for (const token of tokens) counts.set(token, (counts.get(token) || 0) + 1);
    for (const [word, count] of counts) {
      const likelihood = ((textModel.wordCounts[emotion].get(word) || 0) + 1) / denominator;
      score += count * Math.log(likelihood);
    }
    logScores[emotion] = score;
  }

  const maxScore = Math.max(...Object.values(logScores));
  const scaled = Object.fromEntries(EMOTIONS.map((emotion) => [emotion, Math.exp(logScores[emotion] - maxScore)]));
  const total = Object.values(scaled).reduce((sum, score) => sum + score, 0);
  const scores = Object.entries(scaled).map(([label, score]) => ({ label, score: score / total }));
  scores.sort((a, b) => b.score - a.score);
  return scores;
}

function extractHogFeatures(image) {
  const size = 48;
  const cellSize = 8;
  const bins = 9;
  const canvas = document.createElement("canvas");
  canvas.width = size;
  canvas.height = size;
  const context = canvas.getContext("2d", { willReadFrequently: true });
  context.drawImage(image, 0, 0, size, size);
  const rgba = context.getImageData(0, 0, size, size).data;
  const gray = new Float32Array(size * size);

  for (let i = 0, pixel = 0; i < rgba.length; i += 4, pixel += 1) {
    gray[pixel] = (0.299 * rgba[i] + 0.587 * rgba[i + 1] + 0.114 * rgba[i + 2]) / 255;
  }

  const histogram = new Float32Array(6 * 6 * bins);
  for (let y = 0; y < size; y += 1) {
    for (let x = 0; x < size; x += 1) {
      const index = y * size + x;
      const left = gray[y * size + Math.max(0, x - 1)];
      const right = gray[y * size + Math.min(size - 1, x + 1)];
      const above = gray[Math.max(0, y - 1) * size + x];
      const below = gray[Math.min(size - 1, y + 1) * size + x];
      const dx = x === 0 || x === size - 1 ? right - left : (right - left) * 0.5;
      const dy = y === 0 || y === size - 1 ? below - above : (below - above) * 0.5;
      const magnitude = Math.hypot(dx, dy);
      let angle = Math.atan2(dy, dx) % Math.PI;
      if (angle < 0) angle += Math.PI;
      const position = (angle / Math.PI) * bins;
      const lower = Math.floor(position) % bins;
      const upperWeight = position - Math.floor(position);
      const cell = (Math.floor(y / cellSize) * 6 + Math.floor(x / cellSize)) * bins;
      histogram[cell + lower] += magnitude * (1 - upperWeight);
      histogram[cell + ((lower + 1) % bins)] += magnitude * upperWeight;
    }
  }

  const features = new Float32Array(25 * 36);
  let featureIndex = 0;
  for (let row = 0; row < 5; row += 1) {
    for (let col = 0; col < 5; col += 1) {
      const block = new Float32Array(36);
      let blockIndex = 0;
      let squaredSum = 0;
      for (let cellY = row; cellY < row + 2; cellY += 1) {
        for (let cellX = col; cellX < col + 2; cellX += 1) {
          const start = (cellY * 6 + cellX) * bins;
          for (let bin = 0; bin < bins; bin += 1) {
            const value = histogram[start + bin];
            block[blockIndex++] = value;
            squaredSum += value * value;
          }
        }
      }
      const firstNorm = Math.sqrt(squaredSum + 1e-6);
      squaredSum = 0;
      for (let i = 0; i < block.length; i += 1) {
        block[i] = Math.min(block[i] / firstNorm, 0.2);
        squaredSum += block[i] * block[i];
      }
      const secondNorm = Math.sqrt(squaredSum + 1e-6);
      for (let i = 0; i < block.length; i += 1) features[featureIndex++] = block[i] / secondNorm;
    }
  }
  return features;
}

function predictImage(image) {
  if (!imageModel) throw new Error("The trained image model is still loading. Try again in a moment.");
  const features = extractHogFeatures(image);
  const logits = imageModel.bias.slice();
  for (let featureIndex = 0; featureIndex < features.length; featureIndex += 1) {
    const feature = features[featureIndex];
    const row = imageModel.weights[featureIndex];
    for (let classIndex = 0; classIndex < logits.length; classIndex += 1) {
      logits[classIndex] += feature * row[classIndex];
    }
  }
  const maxLogit = Math.max(...logits);
  const expScores = logits.map((value) => Math.exp(value - maxLogit));
  const total = expScores.reduce((sum, value) => sum + value, 0);
  return imageModel.labels.map((label, index) => ({ label, score: expScores[index] / total }));
}

function canonicalEmotion(label) {
  const lower = label.toLowerCase().trim();
  if (lower === "happy" || lower === "happiness") return "joy";
  if (lower === "sad") return "sadness";
  if (lower === "angry") return "anger";
  return lower;
}

function showResult(scores, source) {
  if (!scores.length) throw new Error("The model did not return a result. Try a different input.");
  const sorted = [...scores].sort((a, b) => b.score - a.score);
  const top = sorted[0];
  const key = canonicalEmotion(top.label);
  const meta = EMOTION_META[key] || EMOTION_META[top.label.toLowerCase()] || { glyph: "✳", explanation: "A visible expression signal from the model." };
  const display = meta.display || key;

  elements.resultEmpty.hidden = true;
  elements.resultContent.hidden = false;
  elements.resultOrb.dataset.emotion = key;
  elements.resultGlyph.textContent = meta.glyph;
  elements.resultTitle.textContent = display;
  elements.resultExplanation.textContent = source === "image" && meta.explanation.includes("words")
    ? "A visible facial-expression signal from the image."
    : meta.explanation;
  elements.resultDisclaimer.textContent = source === "image"
    ? `FER2013 held-out accuracy: ${Math.round(imageModel.test_accuracy * 100)}% · expression is not inner feeling.`
    : "Relative scores from a tiny dataset — not calibrated probabilities.";

  elements.scoreList.replaceChildren();
  for (const item of sorted.slice(0, 4)) {
    const emotionKey = canonicalEmotion(item.label);
    const row = document.createElement("div");
    row.className = "score-row";
    const label = document.createElement("span");
    label.className = "score-name";
    label.textContent = (EMOTION_META[emotionKey]?.display || emotionKey).toLowerCase();
    const track = document.createElement("span");
    track.className = "score-track";
    const fill = document.createElement("i");
    fill.className = "score-fill";
    fill.style.width = `${Math.max(2, item.score * 100)}%`;
    track.append(fill);
    const value = document.createElement("span");
    value.className = "score-value";
    value.textContent = `${Math.round(item.score * 100)}%`;
    row.append(label, track, value);
    elements.scoreList.append(row);
  }
}

function setBusy(button, busy, text) {
  button.classList.toggle("is-loading", busy);
  button.disabled = busy || (button === elements.analyzeImage && !currentImageUrl);
  button.querySelector("span").textContent = text;
  button.querySelector("b").textContent = busy ? "↻" : "↗";
}

function setMode(mode) {
  const isText = mode === "text";
  elements.textTab.classList.toggle("active", isText);
  elements.imageTab.classList.toggle("active", !isText);
  elements.textTab.setAttribute("aria-selected", String(isText));
  elements.imageTab.setAttribute("aria-selected", String(!isText));
  elements.textMode.hidden = !isText;
  elements.imageMode.hidden = isText;
}

function analyzeImage() {
  if (!currentImageUrl) return;
  setBusy(elements.analyzeImage, true, "Reading expression…");
  try {
    showResult(predictImage(elements.imagePreview), "image");
  } catch (error) {
    alert(`The image model could not finish: ${error.message || "Please try again with a clear, front-facing face photo."}`);
  } finally {
    setBusy(elements.analyzeImage, false, "Read this expression");
  }
}

function selectImage(file) {
  if (!file) return;
  if (!file.type.startsWith("image/")) {
    alert("Choose an image file such as JPG, PNG or WEBP.");
    return;
  }
  if (file.size > 12 * 1024 * 1024) {
    alert("That image is larger than 12 MB. Choose a smaller image.");
    return;
  }
  if (currentImageUrl) URL.revokeObjectURL(currentImageUrl);
  currentImageUrl = URL.createObjectURL(file);
  elements.imagePreview.onload = () => {
    elements.dropzoneEmpty.hidden = true;
    elements.previewWrap.hidden = false;
    elements.imageFileName.textContent = file.name;
    elements.analyzeImage.disabled = !imageModel;
    elements.resultContent.hidden = true;
    elements.resultEmpty.hidden = false;
  };
  elements.imagePreview.onerror = () => {
    elements.analyzeImage.disabled = true;
    alert("This image could not be opened. Try another file.");
  };
  elements.imagePreview.src = currentImageUrl;
}

elements.textTab.addEventListener("click", () => setMode("text"));
elements.imageTab.addEventListener("click", () => setMode("image"));
elements.textInput.addEventListener("input", () => {
  elements.charCount.textContent = `${elements.textInput.value.length} / 400`;
});
elements.textInput.addEventListener("keydown", (event) => {
  if ((event.ctrlKey || event.metaKey) && event.key === "Enter") elements.analyzeText.click();
});
elements.analyzeText.addEventListener("click", () => {
  try {
    showResult(predictText(elements.textInput.value), "text");
  } catch (error) {
    elements.textInput.focus();
    alert(error.message);
  }
});
document.querySelectorAll("[data-example]").forEach((button) => {
  button.addEventListener("click", () => {
    elements.textInput.value = button.dataset.example;
    elements.charCount.textContent = `${elements.textInput.value.length} / 400`;
    elements.textInput.focus();
  });
});
elements.dropzone.addEventListener("click", () => elements.imageInput.click());
elements.imageInput.addEventListener("change", (event) => selectImage(event.target.files[0]));
elements.analyzeImage.addEventListener("click", analyzeImage);
elements.dropzone.addEventListener("dragover", (event) => {
  event.preventDefault();
  elements.dropzone.classList.add("drag-over");
});
elements.dropzone.addEventListener("dragleave", () => elements.dropzone.classList.remove("drag-over"));
elements.dropzone.addEventListener("drop", (event) => {
  event.preventDefault();
  elements.dropzone.classList.remove("drag-over");
  selectImage(event.dataTransfer.files[0]);
});

async function loadTextDataset() {
  try {
    const response = await fetch("emotion_dataset.csv");
    if (!response.ok) throw new Error("Dataset file was not found.");
    const lines = (await response.text()).trim().split(/\r?\n/);
    const rows = lines.slice(1).filter(Boolean).map(parseCsvLine).map(([text, emotion]) => ({ text, emotion }));
    textModel = trainTextModel(rows);
    textModelStatus = `Text: ${rows.length} examples`;
    updateModelStatus();
  } catch (error) {
    textModelStatus = "Text dataset unavailable";
    updateModelStatus();
    console.error(error);
  }
}

async function loadImageModel() {
  try {
    const response = await fetch("image_model.json");
    if (!response.ok) throw new Error("The trained image model file was not found.");
    imageModel = await response.json();
    if (!Array.isArray(imageModel.labels) || imageModel.labels.length !== EMOTIONS.length || imageModel.weights.length !== imageModel.feature_count) {
      throw new Error("The trained image model file is incomplete.");
    }
    if (currentImageUrl) elements.analyzeImage.disabled = false;
    imageModelStatus = `Image: FER2013 trained · ${Math.round(imageModel.test_accuracy * 100)}% held-out`;
    updateModelStatus();
  } catch (error) {
    imageModel = null;
    imageModelStatus = "Image model unavailable";
    updateModelStatus();
    console.error(error);
  }
}

loadTextDataset();
loadImageModel();
